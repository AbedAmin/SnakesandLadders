
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Game extends JPanel {
	
	

	private static final int BOARD_SIZE = 100;
	private static final int SQUARE_SIZE = 70;

	private int player1Position = 0;
	private int player2Position = 0;
	private int currentPlayer = 1;
	private int[] snakes = { 17, 54, 62, 64, 87, 93, 95, 98 };
	private int[] ladders = { 4, 9, 20, 28, 40, 51, 63, 71 };

	private JButton rollButton;
	private JLabel diceLabel;
	public Game() {
		setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		setLayout(null);
		rollButton = new JButton("Roll Dice");
		rollButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		rollButton.setBackground(Color.black);
		rollButton.setForeground(Color.white);
		rollButton.setBounds(700, 500, 184, 200);
		rollButton.addActionListener(new RollButtonListener());
		add(rollButton);

		diceLabel = new JLabel();
		diceLabel.setBounds(750, 300, 184, 200);
		add(diceLabel);
	}

	public void paintComponent(Graphics g) {
	    super.paintComponent(g);
	    for (int i = 1; i < BOARD_SIZE + 1; i++) {
	        int x = ((i - 1) % 10) * SQUARE_SIZE;
	        int y = (10 - (i - 1) / 10 - 1) * SQUARE_SIZE;
	        g.setColor(Color.WHITE);
	        g.fillRect(x, y, SQUARE_SIZE, SQUARE_SIZE);
	        g.setColor(Color.BLACK);
	        g.drawRect(x, y, SQUARE_SIZE, SQUARE_SIZE);
	        g.drawString(Integer.toString(i), x + (SQUARE_SIZE / 2), y + (SQUARE_SIZE / 2));
	    }
	    g.setColor(Color.blue);
	    int x = (player1Position % 10) * SQUARE_SIZE;
	    int y = (10 - player1Position / 10 - 1) * SQUARE_SIZE;
	    if (player1Position >= 100) {
	        player1Position = 0;
	    }
	    g.fillOval(x, y, 25, 25);
	    g.setColor(Color.red);
	    int x2 = (player2Position % 10) * SQUARE_SIZE;
	    int y2 = (10 - player2Position / 10 - 1) * SQUARE_SIZE;
	    if (player2Position >= 100) {
	        player2Position = 0;
	    }
	    g.fillOval(x2, y2, 25, 25);
	}

	private class RollButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Random random = new Random();
			int roll = random.nextInt(6) + 1;
			if (currentPlayer == 1) {
				int newPosition = player1Position + roll;
				if (newPosition >= BOARD_SIZE) {
					newPosition = BOARD_SIZE - 1;
				}
				for (int i = 0; i < snakes.length; i++) {
					if (newPosition == snakes[i]) {
						newPosition = snakes[i] - roll;
						break;
					}
				}
				for (int i = 0; i < ladders.length; i++) {
					if (newPosition == ladders[i]) {
						newPosition = ladders[i] + roll;
						break;
					}
				}
				player1Position = newPosition;
				currentPlayer = 2;
			} else {
				int newPosition = player2Position + roll;
				if (newPosition >= BOARD_SIZE) {
					newPosition = BOARD_SIZE - 1;
				}
				for (int i = 0; i < snakes.length; i++) {
					if (newPosition == snakes[i]) {
						newPosition = snakes[i] - roll;
						break;
					}
				}
				for (int i = 0; i < ladders.length; i++) {
					if (newPosition == ladders[i]) {
						newPosition = ladders[i] + roll;
						break;
					}
				}
				player2Position = newPosition;
	
				currentPlayer = 1;
			}
			repaint();
			switch (roll) {
			case 1:
				diceLabel.setIcon(new ImageIcon("dice 1.jpg"));
				break;
			case 2:
				diceLabel.setIcon(new ImageIcon("dice 2.jpg"));
				break;
			case 3:
				diceLabel.setIcon(new ImageIcon("dice 3.jpg"));
				break;
			case 4:
				diceLabel.setIcon(new ImageIcon("dice 4.jpg"));
				break;
			case 5:
				diceLabel.setIcon(new ImageIcon("dice 5.jpg"));
				break;
			case 6:
				diceLabel.setIcon(new ImageIcon("dice 6.jpg"));
				break;
			}
		}
	}

	public static void main(String[] args) {
		JFrame frame = new JFrame("Snakes Ladders");
		frame.setBackground(Color.black);
		frame.setSize(900, 733);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Game panel = new Game();
		frame.getContentPane().add(panel);
		frame.setResizable(false);
		frame.setVisible(true);
	
		
	}
}