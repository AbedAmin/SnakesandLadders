/** @author Abed and Haleema
 *  Program: This will be the first screen of our Program. It will include information and images.
 */

/**==============================================================IMPORTS==============================================================*/

/** This three imports are from the "java.awt" package and are used for creating colors, fonts, and images .*/ //Done by: Both Students
import java.awt.Color;//Represents Colors
import java.awt.Container;
import java.awt.Font;//Represents Font
import java.awt.GridLayout;
import java.awt.Image;//Represents Image

/**This two imports are from the "java.awt.event" package and are used for handling action events, such as button clicks.*/
import java.awt.event.ActionEvent;//Represent an Action Event (Such as a button press)
import java.awt.event.ActionListener;//Used to handle the Actions of the Action Event.

/**This two imports are from the "java.net" package and are used for working with URLs and handling malformed URLs.*/
import java.net.MalformedURLException;//Create a URL from an incorrect specification
import java.net.URL;//Represents URLs and interact with resources on the internet.

/**This six imports are from the "javax.swing" package and are used for creating various types of GUI components, such as buttons, labels, and frames.*/
import javax.swing.Icon;//Creating and manipulating icons.
import javax.swing.ImageIcon;//Creating and manipulating images.
import javax.swing.JButton;//Creating Buttons
import javax.swing.JLabel;//Creating Labels
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JFrame;//Creating the top-level container for a Swing applications.

public class Menu{

	// Variables - Done by: Abed
	JFrame frame = new JFrame();// Frame .
	JButton enterbutton = new JButton();// Button - Allows the user to start the game.
	JButton controlsbutton = new JButton();// Button - Allows the user to see controls.
	JButton instructionsbutton = new JButton();// Button - Allows the user to go to instruction Page.
	JButton leavebutton = new JButton();// Button - Allows the user to exit the men.
	
	public Menu() {

		// Frame - Done by: Abed
		frame.setTitle("Snakes & Ladders"); // Frame Name
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// Can exit by clicking X
		frame.getContentPane().setLayout(null);// Positions the components
		frame.setVisible(true);// Makes the Frame Visible
		frame.setResizable(false);// Blocks the user form expanding the page
		frame.setSize(900, 800);// Frame Size

		//Background
		JLabel Bg = new JLabel("New label");
		Bg.setIcon(new ImageIcon(Title.class.getResource("/Image/Menu Page.png")));
		Bg.setBounds(-40, 0, 1000, 693);

		// Frame Size - Done by: Haleema
		frame.setSize(973, 693);

		// Image logo - Done by: Abed
		ImageIcon logo = new ImageIcon("Icon.png");
		frame.setIconImage(logo.getImage());

		// Game Button - Done by: Abed
		enterbutton.setText("Enter");// Being Button Name
		enterbutton.setFont(new Font("Times New Roman", Font.PLAIN, 30));// Font of Title
		enterbutton.setBounds(350, 203, 300, 75);
		enterbutton.setForeground(Color.white);
		enterbutton.setBackground(Color.black);
		enterbutton.setFocusable(false);
		enterbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Game game= new Game();
				game.setVisible(true);
				frame.dispose();
			}
		});

		// InstructionButton - Done by: Abed
		instructionsbutton.setText("Instruction");// Instruction Button Name
		instructionsbutton.setFont(new Font("Times New Roman", Font.PLAIN, 30));// Font of Title
		instructionsbutton.setBounds(350, 317, 300, 75);
		instructionsbutton.setForeground(Color.white);
		instructionsbutton.setBackground(Color.black);
		instructionsbutton.setFocusable(false);
		instructionsbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Instructions();
				frame.dispose();
			}
		});
		
		// ControlsButton - Done by: Abed
		controlsbutton.setText("Controls");// Being Button Name
		controlsbutton.setFont(new Font("Times New Roman", Font.PLAIN, 30));// Font of Title
		controlsbutton.setBounds(350, 427, 300, 75);
		controlsbutton.setForeground(Color.white);
		controlsbutton.setBackground(Color.black);
		controlsbutton.setFocusable(false);
		controlsbutton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			new Controls();
			frame.dispose();
		}
	});

		// ExitButton - Done by: Abed
		leavebutton.setText("Leave");// Exit Button Name
		leavebutton.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		leavebutton.setBounds(350, 536, 300, 75);
		leavebutton.setForeground(Color.white);
		leavebutton.setBackground(Color.black);
		leavebutton.setFocusable(false);
		leavebutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirm = JOptionPane.showOptionDialog(null, "Are you sure you want to exit?", "Exit Confirmation",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
				if (confirm == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		

		// InstructionButton - Done by: Haleema
		frame.getContentPane().add(enterbutton);
		frame.getContentPane().add(instructionsbutton);
		frame.getContentPane().add(controlsbutton);
		frame.getContentPane().add(leavebutton);
		frame.getContentPane().add(Bg);

	}
}