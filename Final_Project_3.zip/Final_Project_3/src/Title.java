/** @author Abed and Haleema
 *  Program: This will be the first screen of our Program. It will include information and images.
 */

/**==============================================================IMPORTS==============================================================*/

/** This three imports are from the "java.awt" package and are used for creating colors, fonts, and images .*///Done by: Both Students
import java.awt.Color;//Represents Colors
import java.awt.Font;//Represents Font
/**This two imports are from the "java.awt.event" package and are used for handling action events, such as button clicks.*/
import java.awt.event.ActionEvent;//Represent an Action Event (Such as a button press)
import java.awt.event.ActionListener;//Used to handle the Actions of the Action Event.

/**This two imports are from the "java.net" package and are used for working with URLs and handling malformed URLs.*/
import java.net.MalformedURLException;//Create a URL from an incorrect specification
/**This six imports are from the "javax.swing" package and are used for creating various types of GUI components, such as buttons, labels, and frames.*/
import javax.swing.Icon;//Creating and manipulating icons.
import javax.swing.ImageIcon;//Creating and manipulating images.
import javax.swing.JButton;//Creating Buttons
import javax.swing.JLabel;//Creating Labels
import javax.swing.JOptionPane;
import javax.swing.JFrame;

public class Title {

	// Variables - Done by: Abed
	JFrame frame = new JFrame();// Frame Title.
	JButton beginbutton = new JButton();// Begin Button - Allows the user to being the program.
	JButton exitbutton = new JButton();// Leave Button - Allows the user to leave the program.

	public Title() throws MalformedURLException {

		// Frame - Done by: Abed
		frame.setTitle("Snakes & Ladders"); // Frame Name
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// Can exit by clicking X
		frame.getContentPane().setLayout(null);// Positions the components
		frame.setVisible(true);// Makes the Frame Visible
		frame.setResizable(false);//

		// Image logo - Done by: Abed
		ImageIcon logo = new ImageIcon("/Image/Icon.png");
		frame.setIconImage(logo.getImage());

		//Background - By Abed
		JLabel Bg = new JLabel("Image");
		Bg.setIcon(new ImageIcon(Title.class.getResource("/Image/Title Page.png")));
		Bg.setBounds(-40, 0, 1000, 693);

		// Frame Size - Done by: Haleema
		frame.setSize(973,693);

		// Begin - Done by: Abed
		beginbutton.setText("Begin");// Being Button Name
		beginbutton.setFont(new Font("Times New Roman", Font.PLAIN, 30));// Font of Title
		beginbutton.setBounds(273, 399, 400, 75);
		beginbutton.setForeground(Color.white);
		beginbutton.setBackground(Color.black);
		beginbutton.setFocusable(false);

		// Leave - Done by: Abed
		exitbutton.setText("Exit");// Being Leave Name
		exitbutton.setFont(new Font("Times New Roman", Font.PLAIN, 30));// Font of Title
		exitbutton.setBounds(273, 509, 400, 75);
		exitbutton.setForeground(Color.white);
		exitbutton.setBackground(Color.black);
		exitbutton.setFocusable(false);

		// Process: User will click this to exit the program - Done by: Abed
		exitbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirm = JOptionPane.showOptionDialog(null, "Are you sure you want to Leave?", "Exit Confirmation",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
				if (confirm == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		
		frame.getContentPane().add(beginbutton);
		frame.getContentPane().add(exitbutton);
		frame.getContentPane().add(Bg);
		
		// This part of the program will take the user to the Menu Page - Done by:ABed
		beginbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Menu();
				frame.dispose();
			}
		});
	}
}