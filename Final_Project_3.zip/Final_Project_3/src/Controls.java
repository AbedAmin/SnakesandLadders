import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Controls {

	// Variables - Done by: Abed
	JFrame frame = new JFrame();// Frame .
	JButton goback = new JButton();// Button - Allows the user to leave to the menu.

	public Controls() {

		// Frame - Done by: Abed
		frame.setTitle("Snakes & Ladders"); // Frame Name
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// Can exit by clicking X
		frame.getContentPane().setLayout(null);// Positions the components
		frame.setVisible(true);// Makes the Frame Visible
		frame.setResizable(false);// Blocks the user form expanding the page
		frame.setSize(1415, 780);// Frame Size
		
		// Image logo - Done by: Abed
		ImageIcon logo = new ImageIcon("Icon.png");
		frame.setIconImage(logo.getImage());
		
		// Background
		JLabel Bg = new JLabel("New label");
		Bg.setIcon(new ImageIcon(Title.class.getResource("/Image/Controls Image.png")));
		Bg.setBounds(0, -15, 1379, 697);

		// Frame Size - Done by: Haleema
		frame.setSize(1397, 700);

		// ExitButton - Done by: Abed
		goback.setText("Go Back");// Exit Button Name
		goback.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		goback.setBounds(46, 51, 300, 75);
		goback.setForeground(Color.white);
		goback.setBackground(Color.black);
		goback.setFocusable(false);
		goback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Menu();
				frame.dispose();
			}
		});

		// InstructionButton - Done by: Haleema
		frame.getContentPane().add(goback);
		frame.getContentPane().add(Bg);

	}
}