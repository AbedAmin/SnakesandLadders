import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Instructions {

	// Variables - Done by: Abed
	JFrame frame = new JFrame();// Frame .
	JButton goback = new JButton();// Button - Allows the user to leave to the menu.

	public Instructions() {

		// Frame - Done by: Abed
		frame.setTitle("Snakes & Ladders"); // Frame Name
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// Can exit by clicking X
		frame.setLayout(null);// Positions the components
		frame.setVisible(true);// Makes the Frame Visible
		frame.setResizable(false);// Blocks the user form expanding the page
		
		// Image logo - Done by: Abed
		ImageIcon logo = new ImageIcon("/Image/Icon.png");
		frame.setIconImage(logo.getImage());
		
		// Background
		JLabel Bg = new JLabel("New label");
		Bg.setIcon(new ImageIcon(Title.class.getResource("/Image/Instructions Page.png")));
		Bg.setBounds(-40, 0, 1440, 589);

		// Frame Size - Done by: Haleema
		frame.setSize(1415, 589);
				
		// ExitButton - Done by: Abed
		goback.setText("Go Back");// Exit Button Name
		goback.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		goback.setBounds(50, 50, 200, 75);
		goback.setForeground(Color.white);
		goback.setBackground(Color.black);
		goback.setFocusable(false);
		goback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Menu();
				frame.dispose();
			}
		});

		// InstructionButton - Done by: Haleema
		frame.add(goback);
		frame.getContentPane().add(Bg);

	}
}